import java.util.Comparator;

import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.Queue;

public class Solver {
    private Board initial;
    private Queue<Board> tempQ = new Queue<Board>();
    private int numOfMoves = 0;    // 用于防止initial同时占用 previous and previousClose
                           // 顺便给moves方法用。。

    // find a solution to the initial board (using the A* algorithm)
    public Solver(Board initial) {
        if (initial == null)
            throw new NullPointerException();
        Board previous = null, previousClose = null;
        this.initial = initial;
        MinPQ<Pack> pq = new MinPQ<>(new BoardComparator());
        previous = initial;
        
        Pack minNode = null;    // 用于存放pq中弹出的min
        pq.insert(new Pack(0, initial));
        if (initial.twin().hamming() != 0) {    // 剔除无法解决的
            while (pq.min().getBoard().hamming() != 0) {
                minNode = pq.delMin();
                numOfMoves = minNode.getMoves();
                for (Board board : minNode.getBoard().neighbors()) {
                    if (!board.equals(previous))    // 优化,防止走回头路
                        pq.insert(new Pack (numOfMoves + 1, board));
                }
                tempQ.enqueue(minNode.getBoard());
                
                if (numOfMoves++ == 0)    // 在第一次运行的时候，直接跳过else里面的。
                    ;
                else
                    previous = previousClose;
                previousClose = minNode.getBoard();    // 存储最新弹出的那个，准备在下次循环的时候变成previous
            }
            tempQ.enqueue(pq.delMin().getBoard());
        }
    }
    
    private class Pack {
        public int moves;
        public Board a;
        public Pack (int i, Board a) {
            moves = i;
            this.a = a;
        }
        
        public int getMoves() {
            return moves;
        }
        
        public Board getBoard() {
            return a;
        }
    }
    
    private class BoardComparator implements Comparator<Pack> {
        @Override
        public int compare(Pack arg0, Pack arg1) {
            if (arg0.getMoves() + arg0.getBoard().manhattan() >arg1.getMoves() + arg1.getBoard().manhattan() )
                return 1;
            else if (arg0.getMoves() + arg0.getBoard().manhattan() == arg1.getMoves() + arg1.getBoard().manhattan())
                return 0;
            else
                return -1;
        }
        /*public int compare(Pack arg0, Pack arg1) {
            if (arg0.getBoard().hamming() + arg0.getMoves() + arg0.getBoard().manhattan() > arg1.getBoard().hamming() + arg1.getMoves() + arg1.getBoard().manhattan() )
                return 1;
            else if (arg0.getBoard().hamming() + arg0.getMoves() + arg0.getBoard().manhattan() == arg1.getBoard().hamming() + arg1.getMoves() + arg1.getBoard().manhattan())
                return 0;
            else
                return -1;
        }*/
    }

    // is the initial board solvable?
    public boolean isSolvable() {
        if (initial.twin().hamming() == 0)
            return false;
        else
            return true;
    }

    // min number of moves to solve initial board; -1 if unsolvable
    public int moves() {
        if (!isSolvable())
            return -1;
        else
            return numOfMoves;
    }

    // sequence of boards in a shortest solution; null if unsolvable
    public Iterable<Board> solution() {
        if (!isSolvable()) 
            return null;
        else
            return tempQ;
    }

    // solve a slider puzzle (given below)
    public static void main(String[] args) {
        // create initial board from file
        int n = StdIn.readInt();
        int[][] blocks = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                blocks[i][j] = StdIn.readInt();
        Board initial = new Board(blocks);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }
}