import java.util.Comparator;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.Queue;

public class Solver {
    private Board initial;
    private Queue<Board> tempQ = new Queue<Board>();
    private int numOfMoves = 0;    // 用于防止initial同时占用 previous and previousClose
                           // 顺便给moves方法用。。

    // find a solution to the initial board (using the A* algorithm)
    public Solver(Board initial) {
        Board previous = null, previousClose = null;
        this.initial = initial;
        MinPQ<Board> pq = new MinPQ<>(new BoardComparator());
        previous = initial;
        
        pq.insert(initial);
        tempQ.enqueue(initial);
        Board top = initial;    // 用于存放pq中弹出的min
        while (pq.min().hamming() != 0) {
            for (Board board : top.neighbors()) {
                if (!board.equals(previous))    // 优化,防止走回头路
                    pq.insert(board);
            }
            top = pq.delMin();
            tempQ.enqueue(top);
            if (numOfMoves++ == 0)    // 在第一次运行的时候，直接跳过else里面的。
                ;
            else
                previous = previousClose;
            previousClose = top;    // 存储最新弹出的那个，准备在下次循环的时候变成previous
        }
    }
    
    private class BoardComparator implements Comparator<Board> {
        @Override
        public int compare(Board arg0, Board arg1) {
            if (arg0.hamming() > arg1.hamming())
                return 1;
            else if (arg0.hamming() == arg1.hamming())
                return 0;
            else
                return -1;
        }
    }

    // is the initial board solvable?
    public boolean isSolvable() {
        if (initial.twin().hamming() == 0)
            return false;
        else
            return true;
    }

    // min number of moves to solve initial board; -1 if unsolvable
    public int moves() {
        if (!isSolvable())
            return -1;
        else
            return numOfMoves;
    }

    // sequence of boards in a shortest solution; null if unsolvable
    public Iterable<Board> solution() {
        if (!isSolvable()) 
            return null;
        else
            return tempQ;
    }

    // solve a slider puzzle (given below)
    public static void main(String[] args) {
        // create initial board from file
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] blocks = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                blocks[i][j] = in.readInt();
        Board initial = new Board(blocks);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }
}