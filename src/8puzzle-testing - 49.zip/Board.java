import java.util.Iterator;

import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.Stack;

public class Board {
    private int[][] blocks = null;
    private int n, moves;

    // construct a board from an n-by-n array of blocks
    // (where blocks[i][j] = block in row i, column j)
    public Board(int[][] blocks) {
        this.blocks = blocks.clone();
        for (int i = 0; i < blocks.length; i++) {
            this.blocks[i] = blocks[i].clone();
        }
        n = blocks.length;
        moves = 0;
    }

    // board dimension n
    public int dimension() {
        return n;
    }

    // number of blocks out of place
    public int hamming() {
        int right = 1, count = 0;
        for (int i = 0; i < blocks.length; i++) {
            for (int j = 0; j < blocks[i].length; j++, right++) {
                if (i == n - 1 && j == n - 1 && blocks[i][j] != 0)
                    count++;
                else if (blocks[i][j] != right && blocks[i][j] != 0) {
                    count++;
                }
            }
        }
        return count;
    }

    // sum of Manhattan distances between blocks and goal
    public int manhattan() {
        int count = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                int rightNum = i * n + j + 1;
                if (blocks[i][j] == rightNum || blocks[i][j] == 0)
                    ;
                else {
                    int row = (blocks[i][j] - 1) / n;
                    int col = blocks[i][j] - 1 - row * n;
                    int manhattanNum = Math.abs(i - row) + Math.abs(j - col);
                    count += manhattanNum;
                }
            }
        }
        return count;
    }

    // is this board the goal board?
    public boolean isGoal() {
        return hamming() == 0;
    }

    // a board that is obtained by exchanging any pair of blocks
    public Board twin() {
        int[][] temp = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                temp[i][j] = blocks[i][j];
            }
        }
        int zeroIndexI = 0, zeroIndexJ = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (temp[i][j] == 0) {
                    zeroIndexI = i;
                    zeroIndexJ = j;
                }
            }
        }
        int randomI1 = 0, randomI2 = 0, randomJ1 = 0, randomJ2 = 0;
        if (hamming() != 2) {
            while (randomI1 == randomI2 && randomJ1 == randomJ2 || 
                    randomI1 ==  zeroIndexI && randomJ1 == zeroIndexJ ||
                    randomI2 ==  zeroIndexI && randomJ2 == zeroIndexJ ) { // 为了不碰到0的位置
                randomI1 = StdRandom.uniform(n); 
                randomI2 = StdRandom.uniform(n);
                randomJ1 = StdRandom.uniform(n);
                randomJ2 = StdRandom.uniform(n);
            }
            swap(randomI1, randomJ1, randomI2, randomJ2, temp);
        }
        else {
            int count = 0;
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (temp[i][j] != i * n + j + 1 && count == 0 && temp[i][j] != 0) {
                        randomI1 = i;
                        randomJ1 = j;
                        count++;
                    }
                    else if (temp[i][j] != i * n + j + 1 && count == 1 && temp[i][j] != 0) {
                        randomI2 = i;
                        randomJ2 = j;
                    }
                }
            }
            swap(randomI1, randomJ1, randomI2, randomJ2, temp);
        }

        return new Board(temp);
    }

    // does this board equal y?
    public boolean equals(Object y) {
        if (y == this)
            return true;
        if (y == null)
            return false;
        if (y.getClass() != this.getClass())
            return false;
        Board tempY = (Board) y;
        if (blocks.length != tempY.blocks.length)
            return false;
        for (int i = 0; i < n; i++) {
            if (blocks[i].length != tempY.blocks[i].length)
                return false;
            for (int j = 0; j < n; j++) {
                if (blocks[i][j] != tempY.blocks[i][j])
                    return false;
            }
        }
        return true;
    }

    // all neighboring boards
    public Iterable<Board> neighbors() {
        Stack<Board> ha = new Stack<>();
        int zeroIndexI = 0, zeroIndexJ = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (blocks[i][j] == 0) {
                    zeroIndexI = i;
                    zeroIndexJ = j;
                }
            }
        }
        int index = zeroIndexJ + zeroIndexI * n;
        /*
         * if (index == 0 || index == n - 1 || index == n * n - 1 || index == n * n - n) { cases = 2; } else if (index > 0 && index < n - 1 || index > n * n - n
         * && index < n * n - 1) { cases = 3; } else { cases = 4; }
         */
        /*
         * 下面这段用于解决首位以及首尾两行的问题，其他部位无法解决。 用下标解决这个问题。 直接对index加减1，加减n，如果加减结果<0 或 > n*n - 1 则舍弃，因为outOfBound了
         */
        if (index - 1 >= 0 && index / n == (index - 1) / n) {
            int[][] blocksCopy1 = copyBlocks();
            int temp = index - 1;
            int modZeroIndexI = temp / n;
            int modZeroIndexj = temp - modZeroIndexI * n;
            swap(zeroIndexI, zeroIndexJ, modZeroIndexI, modZeroIndexj, blocksCopy1);
            Board a = new Board(blocksCopy1);
            a.movesPlus(moves);
            ha.push(a);
        }

        if (index + 1 <= n * n - 1 && index / n == (index + 1) / n) {
            int[][] blocksCopy1 = copyBlocks();
            int temp = index + 1;
            int modZeroIndexI = temp / n;
            int modZeroIndexj = temp - modZeroIndexI * n;
            swap(zeroIndexI, zeroIndexJ, modZeroIndexI, modZeroIndexj, blocksCopy1);
            Board a = new Board(blocksCopy1);
            a.movesPlus(moves);
            ha.push(a);
        }

        if (index - n >= 0) {
            int[][] blocksCopy1 = copyBlocks();
            int temp = index - n;
            int modZeroIndexI = temp / n;
            int modZeroIndexj = temp - modZeroIndexI * n;
            swap(zeroIndexI, zeroIndexJ, modZeroIndexI, modZeroIndexj, blocksCopy1);
            Board a = new Board(blocksCopy1);
            a.movesPlus(moves);
            ha.push(a);
        }

        if (index + n <= n * n - 1) {
            int[][] blocksCopy1 = copyBlocks();
            int temp = index + n;
            int modZeroIndexI = temp / n;
            int modZeroIndexj = temp - modZeroIndexI * n;
            swap(zeroIndexI, zeroIndexJ, modZeroIndexI, modZeroIndexj, blocksCopy1);
            Board a = new Board(blocksCopy1);
            a.movesPlus(moves);
            ha.push(a);
        }

        return ha;
    }

    /**
     * 交换二维数组a中两个数值的位置，前四个参数为index。
     */
    private void swap(int i1, int j1, int i2, int j2, int[][] a) {
        int temp = a[i1][j1];
        a[i1][j1] = a[i2][j2];
        a[i2][j2] = temp;
    }

    private int[][] copyBlocks() {
        int[][] temp = blocks.clone();
        for (int i = 0; i < blocks.length; i++) {
            temp[i] = blocks[i].clone();
        }
        return temp;
    }

    private void movesPlus(int i) {
        moves = i + 1;
    }
    

    // string representation of this board (in the output format specified below)
    public String toString() {
        /*
         * String temp = n + "\n"; for (int i = 0; i < n; i++) { for (int j = 0; j < n; j++) { temp += " "; temp += blocks[i][j]; } temp += "\n"; } return temp;
         */
        StringBuilder s = new StringBuilder();
        s.append(n + "\n");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                s.append(String.format("%2d ", blocks[i][j]));
            }
            s.append("\n");
        }
        return s.toString();
    }

    public static void main(String[] args) {
        // unit tests (not graded)
    }
}