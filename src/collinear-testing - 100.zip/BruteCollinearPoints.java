import java.util.ArrayList;

public class BruteCollinearPoints {
    private int num = 0;
    private LineSegment[] lineSeg = null;
    private ArrayList<LineSegment> al = null;

    // finds all line segments containing 4 points
    public BruteCollinearPoints(Point[] points) {
        if (points == null)
            throw new NullPointerException();

        al = new ArrayList<LineSegment>();

        for (int i = 0; i < points.length; i++) {
            for (int j = i + 1; j < points.length; j++) {
                if (points[i].compareTo(points[j]) == 0)    //check duplicate point
                    throw new IllegalArgumentException();
                
                for (int k = j + 1; k < points.length; k++) {
                    if (points[j].compareTo(points[k]) == 0 || points[i].compareTo(points[k]) == 0)    //check duplicate point
                        throw new IllegalArgumentException();
                    
                    for (int l = k + 1; l < points.length; l++) {
                        if (points[k].compareTo(points[l]) == 0 || points[j].compareTo(points[l]) == 0 || points[i].compareTo(points[l]) == 0)    //check duplicate point
                            throw new IllegalArgumentException();
                        
                        Point[] temp = {points[i], points[j], points[k], points[l]};
                        
                        for (Point a : temp) {
                            if (a == null)
                                throw new NullPointerException();
                        }
                        
                        /*for (int h = 0; h < temp.length - 1; h++) {
                            for (int g = h + 1; g < temp.length; g++) {
                                if (points[h].compareTo(points[g]) == 0)
                                    throw new IllegalArgumentException();
                            }
                        }*/
                        if (Double.compare(points[i].slopeTo(points[j]), points[j].slopeTo(points[k])) == 0 &&
                                Double.compare(points[j].slopeTo(points[k]), points[k].slopeTo(points[l])) == 0) {
                            
                            num++;
                            Point head = points[i], tail = points[k];
                           
                            for (Point a : temp) {
                                if (a.compareTo(head) < 0)
                                    head = a;
                                if (a.compareTo(tail) > 0)
                                    tail = a;
                            }
                            
                            al.add(new LineSegment(head, tail));
                        }
                    }
                }
            }

        }
    }

    public int numberOfSegments() {
        // the number of line segments
        return num;
    }

    public LineSegment[] segments() {
        // the line segments
        lineSeg = al.toArray(new LineSegment[num]);
        LineSegment[] lineSeg1 = new LineSegment[lineSeg.length];
        System.arraycopy(lineSeg, 0, lineSeg1, 0, lineSeg.length);
        return lineSeg1;
    }
}