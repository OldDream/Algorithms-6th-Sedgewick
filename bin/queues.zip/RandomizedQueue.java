import java.util.Iterator;

import edu.princeton.cs.algs4.StdRandom;

public class RandomizedQueue<Item> implements Iterable<Item> {
    private NodeA<Item> first, last;
    private int count;

    public RandomizedQueue() {    // construct an empty randomized queue

    }

    public boolean isEmpty() {    // is the queue empty?
        return count == 0;
    }

    public int size() {    // return the number of items on the queue
        return count;
    }

    public void enqueue(Item item) {    // add the item
        if (item == null) {
            throw new java.lang.NullPointerException("Don't add null.");
        }
        NodeA<Item> oldfirst = first;
        first = new NodeA<Item>();    // 更新first节点
        first.item = item;
        first.next = oldfirst;
        if (oldfirst == null) {    // 创建第一个节点时首位指向同一个节点
            last = first;
        }
        else {
            oldfirst.previous = first;
        }
        count++;
    }

    public Item dequeue() {    // remove and return a random item
        if (last == null) {
            throw new java.util.NoSuchElementException("Empty deque.");
        }
        int index = StdRandom.uniform(size());
        if (index == 0) {
            if (count == 1) {
                last = null;
            }
            Item item = first.item;
            first = first.next;
            if (first != null) {
                first.previous = null;
            }  
            count--;
            return item;
        }
        else if (index == count - 1) {
            Item item = last.item;
            last.previous.next = null;
            last = last.previous;
            if (last != null) {
                last.next = null;
            }
            count--;
            return item;
        }
        else if (index < count / 2) {
            NodeA<Item> temp = first;
            for (int i = 0; i <= index; i++) {
                if (i == index) {
                    Item item = temp.item;
                    temp.previous.next = temp.next;
                    temp.next.previous = temp.previous;
                    count--;
                    return item;
                }
                else
                    temp = temp.next;
            }
        }
        NodeA<Item> temp = last;
        Item item = temp.item;
        for (int i = count - 1; i >= index; i--) {
            if (i == index) {
                item = temp.item;
                temp.previous.next = temp.next;
                temp.next.previous = temp.previous;
                count--;
                break;
            }
            else
                temp = temp.previous;
        }
        
        return item;
       

    }

    public Item sample() {    // return (but do not remove) a random item
        if (last == null) {
            throw new java.util.NoSuchElementException("Empty deque.");
        }
        int index = StdRandom.uniform(count);
        if (index < count / 2) {
            NodeA<Item> temp = first;
            for (int i = 0; i <= index; i++) {
                if (i == index)
                    return temp.item;
                else
                    temp = temp.next;
            }
        }
        NodeA<Item> temp = last;
        Item item = temp.item;
        for (int i = count - 1; i >= index; i--) {
            if (i == index) {
                item = temp.item;
                break;
            }
            else
                temp = temp.previous;
        }
        return item;
    }

    public Iterator<Item> iterator() {    // return an independent iterator over items in random order
        return new RandomizedIterator();
    }
    
    private class RandomizedIterator implements Iterator<Item> {
        private Item[] rq;
        private int current;
        
        public RandomizedIterator() {
            current = 0;
            rq = (Item[]) new Object[count];
            NodeA<Item> temp = first;
            for (int i = 0; i < count; i++) {
                rq[i] = temp.item;
                temp = temp.next;
            }
            StdRandom.shuffle(rq);
        }

        @Override
        public boolean hasNext() {
            return current <= count - 1;
        }

        @Override
        public Item next() {
            if (current == count) {
                throw new  java.util.NoSuchElementException("Empty.");
            }
            
            Item item = rq[current];
            current++;     
            return item;
        }
        
        @Override
        public void remove() {
            throw new java.lang.UnsupportedOperationException();
        }
        
    }

    private class NodeA<T> {
        private T item;
        private NodeA<T> next;
        private NodeA<T> previous;
    }

    public static void main(String[] args) {    // unit testing (optional)

    }
}
