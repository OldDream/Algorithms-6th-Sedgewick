import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.Stack;

public class Solver {
    private BoardNode targetNode;

    private class BoardNode implements Comparable<BoardNode> {
        int moves;
        int priorityNum;    // 计算优先度用的那个数
        boolean isTwin;    // 调用twin方法之后，手工调整为FALSE
        Board thisBoard;
        BoardNode previousNode;

        public BoardNode(int moves, int priorityNum, boolean isTwin, Board thisNode, BoardNode previous) {
            this.moves = moves;
            this.priorityNum = priorityNum;
            this.isTwin = isTwin;
            this.thisBoard = thisNode;
            this.previousNode = previous;
        }

        @Override
        public int compareTo(BoardNode arg0) {
            if (priorityNum + moves > arg0.priorityNum + arg0.moves)
                return 1;
            else if (priorityNum + moves == arg0.priorityNum + arg0.moves)
                return 0;
            else
                return -1;
        }
    }

    // find a solution to the initial board (using the A* algorithm)
    public Solver(Board initial) {
        MinPQ<BoardNode> pq = new MinPQ<>();
        pq.insert(new BoardNode(0, initial.manhattan(), false, initial, null));
        Board temptwin = initial.twin();
        pq.insert(new BoardNode(0, temptwin.manhattan(), true, temptwin, null));

        while (!pq.isEmpty()) {
            targetNode = pq.delMin();
            
            if (targetNode.thisBoard.manhattan() == 0) {
                if (targetNode.isTwin)
                    targetNode = null;
                break;
            }
            
            for (Board b : targetNode.thisBoard.neighbors()) {
                if (targetNode.previousNode == null || !b.equals(targetNode.previousNode.thisBoard))
                    pq.insert(new BoardNode(targetNode.moves + 1, b.manhattan(), targetNode.isTwin, b, targetNode));
            }
            
        }

    }

    // is the initial board solvable?
    public boolean isSolvable() {
        return targetNode != null;
    }

    // min number of moves to solve initial board; -1 if unsolvable
    public int moves() {
        if (targetNode == null)
            return -1;
        else
            return targetNode.moves;
    }

    // sequence of boards in a shortest solution; null if unsolvable
    // 当找到最终节点之后，从尾巴往前追踪，把一个个节点压到栈里。
    public Iterable<Board> solution() {
        Stack<Board> temp = new Stack<>();
        if (targetNode != null) {
            temp.push(targetNode.thisBoard);
            BoardNode pre = targetNode.previousNode;
            while (pre != null) {
                temp.push(pre.thisBoard);
                pre = pre.previousNode;
            }
            return temp;
        }
        else
            return null;
        
    }

    public static void main(String[] args) {
        // create initial board from file
        int n = StdIn.readInt();
        int[][] blocks = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                blocks[i][j] = StdIn.readInt();
        Board initial = new Board(blocks);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }
}