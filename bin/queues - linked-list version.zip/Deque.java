import java.util.Iterator;

public class Deque<Item> implements Iterable<Item> {
    private Node<Item> first, last;
    private int count;

    public Deque() {    // construct an empty deque 
        first = null;
        last = null;
        count = 0;
    }
    
    public boolean isEmpty() {
        return count == 0;
    }

    public int size() {
        return count;
    }

    public void addFirst(Item item) {    // add the item to the front
        if (item == null) {
            throw new java.lang.NullPointerException("Don't add null.");
        }
        Node<Item> oldfirst = first;
        first = new Node<Item>();    // 更新first节点
        first.item = item;
        first.next = oldfirst;
        
        if (oldfirst == null) {    //创建第一个节点时首位指向同一个节点
            last = first;
        }
        else {
            oldfirst.previous = first;
        }
        count++;
    }

    public void addLast(Item item) {    // add the item to the end
        if (item == null) {
            throw new java.lang.NullPointerException("Don't add null.");
        }
        Node<Item> oldlast = last;
        last = new Node<Item>();    // 更新first节点
        last.item = item;
        last.previous = oldlast;
        
        if (oldlast == null) {    //创建第一个节点时首位指向同一个节点
            first = last;
        }
        else {
            oldlast.next = last;
        }
        count++;
    }

    public Item removeFirst() {    // remove and return the item from the front
        if (first == null) {
            throw new java.util.NoSuchElementException("Empty deque.");
        }
        
        Item item = first.item;
        if (first.next == null) {
            last = null;
            first = null;
        }
        else {        
            first = first.next;
            first.previous = null;
        } 
        count--;
        return item;
    }

    public Item removeLast() {    // remove and return the item from the end
        if (last == null) {
            throw new java.util.NoSuchElementException("Empty deque.");
        }
        
        Item item = last.item;
        if (last.previous == null) {
            last = null;
            first = null;
        }
        else {
            last = last.previous;
            last.next = null;
            
        } 
        count--;
        return item;
    }

    public Iterator<Item> iterator() {    // return an iterator over items in order from front to end
        return new DequeIterator();
    }
    
    private class DequeIterator implements Iterator<Item> {
        private Node<Item> current = first;

        @Override
        public boolean hasNext() {
            return current != null;
        }

        @Override
        public Item next() {
            if (current == null) {
                throw new  java.util.NoSuchElementException("Empty.");
            }
            
            Item item = current.item;
            current = current.next;
            
            return item;
        }
        
        @Override
        public void remove() {
            throw new java.lang.UnsupportedOperationException();
        }
        
    }

    public static void main(String[] args) {
        // unit testing (optional)
    }

    private class Node<T> {
        private T item;
        private Node<T> next;
        private Node<T> previous;
    }
}
