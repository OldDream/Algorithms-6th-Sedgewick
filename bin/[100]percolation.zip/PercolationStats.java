import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;
import edu.princeton.cs.algs4.StdOut;

public class PercolationStats {
    private int trials;
    private double[] x;

    public PercolationStats(int n, int trials) {
        if (n <= 0 || trials <= 0)
            throw new IllegalArgumentException("Invalid n or trials.");
        this.trials = trials;
        x = new double[trials];
        int counter = 0;
        while (counter < trials) {
            Percolation pc = new Percolation(n);
            while (!pc.percolates()) {
                int row = StdRandom.uniform(n) + 1;
                int col = StdRandom.uniform(n) + 1;
                pc.open(row, col);
            }
            x[counter] = 1.0 * pc.numberOfOpenSites() / (n * n);
            counter++;
        }

    }

    public double mean() {
        return StdStats.mean(x);
    }

    public double stddev() {    
        return StdStats.stddev(x);
    }

    public double confidenceLo() {    // low endpoint of 95% confidence interval
        double lo = mean() - 1.96 * stddev() / Math.sqrt(trials);
        return lo;
    }

    public double confidenceHi() {    // high endpoint of 95% confidence interval
        double hi = mean() + 1.96 * stddev() / Math.sqrt(trials);
        return hi;
    }

    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        int trials = Integer.parseInt(args[1]);
        if (n <= 0 || trials <= 0)
            throw new IllegalArgumentException("Invalid n or trials.");
        
        PercolationStats ps = new PercolationStats(n, trials);
        StdOut.println("mean\t\t= " + ps.mean());
        StdOut.println("stddev\t\t= " + ps.stddev());
        StdOut.println("95% confidence interval = [" + ps.confidenceLo() + ", " + ps.confidenceHi() + "]");
    }

}
